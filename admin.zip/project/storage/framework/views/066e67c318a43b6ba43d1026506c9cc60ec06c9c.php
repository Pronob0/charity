
<nav class="navbar navbar-expand-lg navbar-light bg-light my-3">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Dashboard</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="<?php echo e(route('user.transactions')); ?>"><?php echo translate('Transactions'); ?></a>
        </li>
   
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            <?php echo translate('Deposit'); ?>
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
            <li><a class="dropdown-item" href="<?php echo e(route('user.deposit.index')); ?>"><?php echo translate('Deposit'); ?></a></li>
            <li><a class="dropdown-item" href="<?php echo e(route('user.deposit.history')); ?>"><?php echo translate('Deposit History'); ?></a></li>
            
          </ul>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            <?php echo translate('Withdraw'); ?>
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
            <li><a class="nav-link" href="<?php echo e(route('user.withdraw.form')); ?>"><?php echo translate('Withdraw'); ?></a></li>
            <li><a class="dropdown-item" href="<?php echo e(route('user.withdraw.history')); ?>"><?php echo translate('Withdraw History'); ?></a></li>
          </ul>
        </li>
       
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            <?php echo translate('Profile'); ?>
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
            <li><a class="dropdown-item" href="<?php echo e(route('user.profile')); ?>"><?php echo translate('Profile Settings'); ?></a></li>
            <li><a class="dropdown-item" href="<?php echo e(route('user.two.step')); ?>"><?php echo translate('Two Step Authentication'); ?></a></li>
            <li><a class="dropdown-item" href="<?php echo e(route('user.ticket.index')); ?>"><?php echo translate('Support Ticket'); ?></a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="<?php echo e(route('user.logout')); ?>"><?php echo translate('Logout'); ?></a></li>
          </ul>
        </li>

        <li class="nav-item ms-5">
            <select class="language-bar form-control shadow-none" onChange="window.location.href=this.value">
                <?php $__currentLoopData = DB::table('languages')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e(route('lang.change',$item->code)); ?>" <?php echo e(session('lang') == $item->code ? 'selected':''); ?>><?php echo translate($item->language); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </li>

        <li class="nav-item ms-5">
            <select class="language-bar form-control shadow-none" onChange="window.location.href=this.value">
               <option value=""><?php echo translate('Select Currency'); ?></option>
                <?php $__currentLoopData = DB::table('currencies')->where('status',1)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e(route('user.change.currency',$item->id)); ?>" <?php echo e(session('currency') == $item->id ? 'selected':''); ?>><?php echo app('translator')->get($item->code); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </li>
       
      </ul>
    </div>
  </div>
</nav><?php /**PATH C:\xampp\htdocs\admin\project\resources\views/user/partials/header.blade.php ENDPATH**/ ?>