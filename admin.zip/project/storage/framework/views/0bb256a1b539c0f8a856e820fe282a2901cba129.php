
<?php $__env->startSection('title'); ?>
    <?php echo translate('Confirm Deposit'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<?php echo translate('Confirm Deposit'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    

    <div class="row">
        <div class="col-md-12">
            <div class="card shadow-md mb-4 ">
                <div class="card-header text-center">
                 <?php echo translate('Payment Details'); ?>
                </div>
                <div class="card-body">
                    <?php if(Session::has('errors')): ?>
                    <div class="col-12 mt-3 pb-0">
                      <div class="alert alert-danger alert-dismissible fade show" role="alert">
                         <?php echo e(Session::get('errors')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                      </div>
                    </div> 
                    <?php endif; ?>
                    <form action="<?php echo e(route('user.deposit.payment')); ?>" method="POST" id="<?php echo e(Session::get('deposit_data')['keyword']); ?>" >
                        <?php echo csrf_field(); ?>
                    <div class="row text-center">
                        <strong><?php echo translate('Total Payment'); ?> : <?php echo e($currency->symbol.$deposit_data['amount']); ?></strong>
                        <?php if($charge): ?>
                         <strong><?php echo translate('Total Charge'); ?> : <?php echo e($currency->symbol.numFormat($charge,2)); ?></strong>
                        <?php endif; ?>
                        <strong><?php echo translate('Payment Method'); ?> : <?php echo e($gateway->name); ?></strong>
                        <input type="hidden" name="currency" value="<?php echo e($currency->id); ?>">
                        <?php echo $__env->make('other.payment_load', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        <div class="text-center my-4">
                            <button type="submit" id="payment__button" class="btn btn-primary"><?php echo translate('Submit'); ?></button>
                        </div>
                    </div>
                </form>
                </div>
              </div>
        </div>
    </div>

<?php
    $paystack = [];
    if(Session::get('deposit_data')['keyword'] == 'paystack'){
        $paystack = $gateway->convertAutoData();
    }
    if(Session::get('deposit_data')['keyword'] == 'mercadopago'){
        $paydata = $gateway->convertAutoData();
    }
?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script src="https://secure.mlstatic.com/sdk/javascript/v1/mercadopago.js"></script>
<script src="https://js.paystack.co/v1/inline.js"></script>
    <script>
        'use strict'
   $(document).on('submit','#paystack',function(){
                var total = <?php echo e(Session::get('deposit_data')['amount']); ?>;
                total = Math.round(total);
                var handler = PaystackPop.setup({
                key: '<?php echo e(isset($paystack["key"]) ? $paystack["key"] : ''); ?>',
                email: '<?php echo e(Auth::user()->email); ?>',
                amount: total * 100,
                currency: "<?php echo e(getCurrencyCode()); ?>",
                ref: ''+Math.floor((Math.random() * 1000000000) + 1),
                    callback: function(response){
                        $('#ref_id').val(response.reference);
                        $('#paystack').attr('id','');
                        $('#payment__button').click();
                    },
                    onClose: function(){
                        window.location.reload();
                    }
                });
                handler.openIframe();
                 return false;
		});
    </script> 
<?php if(Session::get('deposit_data')['keyword'] == 'mercadopago'): ?>
<script>
    'use strict';

    window.Mercadopago.setPublishableKey("<?php echo e($paydata['public_key']); ?>");
    window.Mercadopago.getIdentificationTypes();

    function addEvent(to, type, fn){ 
      if(document.addEventListener){
          to.addEventListener(type, fn, false);
      } else if(document.attachEvent){
          to.attachEvent('on'+type, fn);
      } else {
          to['on'+type] = fn;
      }  
  }; 

addEvent(document.querySelector('#cardNumber'), 'keyup', guessingPaymentMethod);
addEvent(document.querySelector('#cardNumber'), 'change', guessingPaymentMethod);

function getBin() {
  var ccNumber = document.querySelector('input[data-checkout="cardNumber"]');
  return ccNumber.value.replace(/[ .-]/g, '').slice(0, 6);
};

function guessingPaymentMethod(event) {
  var bin = getBin();

  if (event.type == "keyup") {
      if (bin.length >= 6) {
          window.Mercadopago.getPaymentMethod({
              "bin": bin
          }, setPaymentMethodInfo);
      }
  } else {
      setTimeout(function() {
          if (bin.length >= 6) {
              window.Mercadopago.getPaymentMethod({
                  "bin": bin
              }, setPaymentMethodInfo);
          }
      }, 100);
  }
};

function setPaymentMethodInfo(status, response) {
  if (status == 200) {
      const paymentMethodElement = document.querySelector('input[name=paymentMethodId]');

      if (paymentMethodElement) {
          paymentMethodElement.value = response[0].id;
      } else {
          const input = document.createElement('input');
          input.setAttribute('name', 'paymentMethodId');
          input.setAttribute('type', 'hidden');
          input.setAttribute('value', response[0].id);     

          form.appendChild(input);
      }

      Mercadopago.getInstallments({
          "bin": getBin(),
          "amount": parseFloat(document.querySelector('#amount').value),
      }, setInstallmentInfo);

  } else {
      alert(`payment method info error: ${response}`);  
  }
};



addEvent(document.querySelector('#mercadopago'), 'submit', doPay);
function doPay(event){
  event.preventDefault();

      var $form = document.querySelector('#mercadopago');

      window.Mercadopago.createToken($form, sdkResponseHandler); // The function "sdkResponseHandler" is defined below

      return false;
  
};

function sdkResponseHandler(status, response) {
  if (status != 200 && status != 201) {
      alert("Some of your information is wrong!");
      $('#preloader').hide();

  }else{
      var form = document.querySelector('#mercadopago');
      var card = document.createElement('input');
      card.setAttribute('name', 'token');
      card.setAttribute('type', 'hidden');
      card.setAttribute('value', response.id);
      form.appendChild(card);
 
      form.submit();
  }
};


function setInstallmentInfo(status, response) {
      var selectorInstallments = document.querySelector("#installments"),
      fragment = document.createDocumentFragment();
      selectorInstallments.length = 0;

      if (response.length > 0) {
          var option = new Option("Escolha...", '-1'),
          payerCosts = response[0].payer_costs;
          fragment.appendChild(option);

          for (var i = 0; i < payerCosts.length; i++) {
              fragment.appendChild(new Option(payerCosts[i].recommended_message, payerCosts[i].installments));
          }

          selectorInstallments.appendChild(fragment);
          selectorInstallments.removeAttribute('disabled');
      }
  };



</script>
<?php endif; ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\admin\project\resources\views/user/deposit/payment.blade.php ENDPATH**/ ?>