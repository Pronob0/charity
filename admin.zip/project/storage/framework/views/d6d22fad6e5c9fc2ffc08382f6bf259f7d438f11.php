

<?php $__env->startSection('title'); ?>
   <?php echo translate('Edit Currency'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
 <section class="section">
    <div class="section-header d-flex justify-content-between">
        <h1><?php echo translate('Edit Currency'); ?></h1>
        <a href="<?php echo e(route('admin.currency.index')); ?>" class="btn btn-primary btn-sm"><i class="fas fa-backward"></i> <?php echo translate('Back'); ?></a>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center">
        <div class="col-md-8">
           <div class="card">
                <div class="card-body">
                    <form action="<?php echo e(route('admin.currency.update',$currency->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="form-group col-md-6">
                                <label><?php echo translate('Currency Name'); ?></label>
                                <input class="form-control" type="text" name="curr_name" required value="<?php echo e($currency->curr_name); ?>">
                            </div>
                            <div class="form-group col-md-6">
                                <label><?php echo translate('Currency Code'); ?></label>
                                <input class="form-control" type="text" name="code" required value="<?php echo e($currency->code); ?>">
                            </div>
                            <div class="form-group col-md-6">
                                <label><?php echo translate('Currency Symbol'); ?></label>
                                <input class="form-control" type="text" name="symbol"  required value="<?php echo e($currency->symbol); ?>">
                            </div>
                  
                            <div class="form-group col-md-6">
                                <label><?php echo translate('Currency Rate'); ?></label>
                                <div class="input-group has_append">
                                    <div class="input-group-prepend">
                                        <div class="input-group-text cur_code">1 <?php echo e($gs->curr_code); ?></div>
                                    </div>
                                    <input type="text" class="form-control" placeholder="0" name="rate" value="<?php echo e(numFormat($currency->rate,8)); ?>"/>
                                    <div class="input-group-append">
                                        <div class="input-group-text"><?php echo e($currency->code); ?></div>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group <?php echo e($currency->default == 1 ? 'col-md-12' : 'col-md-6'); ?>">
                                <label><?php echo translate('Currency Type'); ?></label>
                                <select class="form-control" name="type" required>
                                    <option value="">--<?php echo translate('Select Type'); ?>--</option>
                                    <option value="1" <?php echo e($currency->type == 1 ? 'selected':''); ?>><?php echo translate('FIAT'); ?></option>
                                    <option value="2" <?php echo e($currency->type == 2 ? 'selected':''); ?>><?php echo translate('CRYPTO'); ?></option>
                                </select>
                            </div>
                            <?php if($currency->default != 1): ?>
                            <div class="form-group col-md-6">
                                <label><?php echo translate('Set As Default'); ?> </label>
                                <select class="form-control" name="default" required>
                                    <option value="">--<?php echo translate('Select'); ?>--</option>
                                    <option value="1" <?php echo e($currency->default == 1 ? 'selected':''); ?>><?php echo translate('Yes'); ?></option>
                                    <option value="0" <?php echo e($currency->default == 0 ? 'selected':''); ?>><?php echo translate('No'); ?></option>
                                </select>
                            </div>
                            <?php endif; ?>
                            <div class="form-group col-md-12">
                                <label><?php echo translate('Status'); ?> </label>
                                <select class="form-control" name="status" required>
                                    <option value="">--<?php echo translate('Select'); ?>--</option>
                                    <option value="1" <?php echo e($currency->status == 1 ? 'selected':''); ?>><?php echo translate('Active'); ?></option>
                                    <option value="0" <?php echo e($currency->status == 0 ? 'selected':''); ?>><?php echo translate('Inactive'); ?></option>
                                </select>
                            </div>
                        </div>
                       <?php if(access('update currency')): ?>
                       <div class="form-group text-right col-md-12">
                           <button class="btn  btn-primary btn-lg" type="submit"><?php echo translate('Update'); ?></button>
                       </div>
                       <?php endif; ?>
                    </form>
                </div>
           </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\admin\project\resources\views/admin/currency/edit.blade.php ENDPATH**/ ?>