
<?php $__env->startSection('title'); ?>
    <?php echo translate('Admin Dashboard'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
<section class="section">
    <div class="section-header">
        <h1><?php echo translate('Dashboard'); ?></h1>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    
    <?php if(access('dashboard info')): ?>
    <div class="row">
       <div class="col-xl-3 col-lg-4 col-sm-6 col-12">
           <div class="card card-statistic-1">
               <div class="card-icon bg-primary">
                   <i class="far fa-user"></i>
               </div>
               <div class="card-wrap">
                   <div class="card-header">
                       <h4><?php echo translate('Total User'); ?></h4>
                   </div>
                   <div class="card-body">
                      <?php echo e($totalUser); ?>

                   </div>
               </div>
           </div>
       </div>
     
       <div class="col-xl-3 col-lg-4 col-sm-6 col-12">
           <div class="card card-statistic-1">
               <div class="card-icon bg-primary">
                <i class="fas fa-coins"></i>
               </div>
               <div class="card-wrap">
                   <div class="card-header">
                       <h4><?php echo translate('Total Currency'); ?></h4>
                   </div>
                   <div class="card-body">
                      <?php echo e($totalCurrency); ?>

                   </div>
               </div>
           </div>
       </div>
       <div class="col-xl-3 col-lg-4 col-sm-6 col-12">
           <div class="card card-statistic-1">
               <div class="card-icon bg-primary">
                <i class="fas fa-globe"></i>
               </div>
               <div class="card-wrap">
                   <div class="card-header">
                       <h4><?php echo translate('Total Country'); ?></h4>
                   </div>
                   <div class="card-body">
                      <?php echo e($totalCountry); ?>

                   </div>
               </div>
           </div>
       </div>
       <div class="col-xl-3 col-lg-4 col-sm-6 col-12">
           <div class="card card-statistic-1">
               <div class="card-icon bg-primary">
                <i class="fas fa-user-tag"></i>
               </div>
               <div class="card-wrap">
                   <div class="card-header">
                       <h4><?php echo translate('Total Role'); ?></h4>
                   </div>
                   <div class="card-body">
                      <?php echo e($totalRole); ?>

                   </div>
               </div>
           </div>
       </div>
       <div class="col-xl-3 col-lg-4 col-sm-6 col-12">
           <div class="card card-statistic-1">
               <div class="card-icon bg-primary">
                <i class="far fa-user"></i>
               </div>
               <div class="card-wrap">
                   <div class="card-header">
                       <h4><?php echo translate('Total Staff'); ?></h4>
                   </div>
                   <div class="card-body">
                      <?php echo e($totalStaff); ?>

                   </div>
               </div>
           </div>
       </div>
      
       <div class="col-xl-3 col-lg-4 col-sm-6 col-12">
           <div class="card card-statistic-1">
               <div class="card-icon bg-primary">
                 <i class="fas fa-file-invoice-dollar"></i>
               </div>
               <div class="card-wrap">
                   <div class="card-header">
                       <h4><?php echo translate('Default Currency'); ?></h4>
                   </div>
                   <div class="card-body">
                    <?php echo e($gs->curr_code); ?> <sup class="text-danger">*</sup>
                   </div>
               </div>
           </div>
       </div>
   </div>

    <div class="row">
        <div class="col-sm-6 col-12">
            <div class="card card-statistic-2">
                <div class="card-icon shadow-primary bg-success text-white">
                    <?php echo e($gs->curr_sym); ?>

                </div>
                <div class="card-wrap">
                    <div class="card-header">
                       <h4><?php echo translate('Total Deposit'); ?></h4>
                    </div>
                    <div class="card-body">
                        <?php echo e($gs->curr_sym); ?><?php echo e($totalDeposit); ?>

                    </div>
                </div>
            </div>
        </div>
        <div class="col-sm-6 col-12">
            <div class="card card-statistic-2">
            <div class="card-icon shadow-primary bg-primary text-white">
                <?php echo e($gs->curr_sym); ?>

            </div>
            <div class="card-wrap">
                <div class="card-header">
                <h4><?php echo translate('Total Withdraw'); ?></h4>
                </div>
                <div class="card-body">
                    <?php echo e($gs->curr_sym); ?><?php echo e($totalWithdraw); ?>

                </div>
            </div>
            </div>
        </div>
    </div>
   <?php endif; ?>

   <div class="row">
       <div class="col-12 col-md-6 col-lg-6">
           <div class="card">
               <div class="card-header">
                   <h4><?php echo translate('Recent Registered Users'); ?></h4>
               </div>
               <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <tr>
                            <th><?php echo translate('Name'); ?></th>
                            <th><?php echo translate('Email'); ?></th>
                            <th><?php echo translate('Country'); ?></th>
                            <th><?php echo translate('Status'); ?></th>
                            <th><?php echo translate('Action'); ?></th>
                        </tr>
                        <?php $__empty_1 = true; $__currentLoopData = $recentUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                 <td data-label="<?php echo translate('Name'); ?>">
                                   <?php echo e($user->name); ?>

                                 </td>
                                 <td data-label="<?php echo translate('Email'); ?>"><?php echo e($user->email); ?></td>
                                 <td data-label="<?php echo translate('Country'); ?>"><?php echo e($user->country); ?></td>
                                 <td data-label="<?php echo translate('Status'); ?>">
                                    <?php if($user->status == 1): ?>
                                        <span class="badge badge-success"><?php echo translate('active'); ?></span>
                                    <?php elseif($user->status == 2): ?>
                                         <span class="badge badge-danger"><?php echo translate('banned'); ?></span>
                                    <?php endif; ?>
                                 </td>
                                 <?php if(access('edit user')): ?>
                                 <td data-label="<?php echo translate('Action'); ?>">
                                     <a class="btn btn-primary details" href="<?php echo e(route('admin.user.details',$user->id)); ?>"><?php echo translate('Details'); ?></a>
                                 </td>
                                 <?php else: ?>
                                 <td data-label="<?php echo translate('Action'); ?>">
                                   N/A
                                </td>
                                 <?php endif; ?>
                               
                            </tr>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                            <tr>
                                <td class="text-center" colspan="100%"><?php echo translate('No Data Found'); ?></td>
                            </tr>

                        <?php endif; ?>
                    </table>
                  </div>
               </div>
           </div>
       </div>
   </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\admin\project\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>