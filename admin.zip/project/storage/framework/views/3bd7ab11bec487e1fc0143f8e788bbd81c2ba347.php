<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <?php echo $__env->make('other.seo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title><?php echo e(translate($gs->title)); ?>-<?php echo $__env->yieldContent('title'); ?></title>

    <link rel="stylesheet" href="<?php echo e(asset('assets/frontend')); ?>/css/bootstrap.min.css" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/frontend')); ?>/css/all.min.css" />
    <link href="<?php echo e(asset('assets/frontend/css/main.php')); ?>?color=<?php echo e($gs->theme_color); ?>" rel="stylesheet" />
    <link rel="shortcut icon" href="<?php echo e(getPhoto($gs->favicon)); ?>">
</head>
<body>
<?php echo $__env->make('frontend.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->yieldContent('content'); ?>
<div class="fixed--anime">
    <span class="banner-elem elem1">&nbsp;</span>
    <span class="banner-elem elem2">&nbsp;</span>
    <span class="banner-elem elem3">&nbsp;</span>
    <span class="banner-elem elem4">&nbsp;</span>
    <span class="banner-elem elem5">&nbsp;</span>
    <span class="banner-elem elem6">&nbsp;</span>
    <span class="banner-elem elem7">&nbsp;</span>
    <span class="banner-elem elem8">&nbsp;</span>
    <span class="banner-elem elem9">&nbsp;</span>

</div>
<?php echo $__env->make('frontend.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script src="<?php echo e(asset('assets/frontend')); ?>/js/jquery-3.6.0.min.js"></script>
<script src="<?php echo e(asset('assets/frontend')); ?>/js/bootstrap.min.js"></script>
<script src="<?php echo e(asset('assets/frontend')); ?>/js/viewport.jquery.js"></script>
<script src="<?php echo e(asset('assets/frontend')); ?>/js/odometer.min.js"></script>
<script src="<?php echo e(asset('assets/frontend')); ?>/js//owl.min.js"></script>
<script src="<?php echo e(asset('assets/frontend')); ?>/js/main.js"></script>
<?php echo $__env->make('notify.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldPushContent('script'); ?>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\admin\project\resources\views/layouts/auth.blade.php ENDPATH**/ ?>