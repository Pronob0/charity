<html lang="en">
  <head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover"/>
    <meta http-equiv="X-UA-Compatible" content="ie=edge"/>
    <title><?php echo e(translate($gs->title)); ?>-<?php echo $__env->yieldContent('title'); ?></title>
    <!-- CSS files -->
    <link rel="shortcut icon" href="<?php echo e(getPhoto($gs->favicon)); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/font-awsome.min.css')); ?>">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo e(asset('assets/user/')); ?>/css/custom.css" rel="stylesheet"/>
    <?php echo $__env->yieldPushContent('style'); ?>
 
  </head>
  
  <body>
    <div class="container">
          <?php echo $__env->make('user.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <?php echo $__env->yieldContent('content'); ?>
    </div>

      <script src="<?php echo e(asset('assets/admin/js/jquery.min.js')); ?>"></script>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>

      <?php echo $__env->make('notify.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php echo $__env->yieldPushContent('script'); ?>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\admin\project\resources\views/layouts/user.blade.php ENDPATH**/ ?>