

<?php $__env->startSection('title'); ?>
    <?php echo translate('Deposit'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<?php echo translate('Deposit'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="row row-deck row-cards mb-5">
        <div class="col-12">
            <div class="card">
            <div class="card-body">
                <form action="<?php echo e(route('user.deposit.submit')); ?>" id="form" method="post">
                  <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-md-6 mb-2">
                            <div class="form-label "><?php echo translate('Amount : '); ?>  </div>
                            <div class="input-group">
                                <input type="text" name="amount" id="amount" class="form-control shadow-none"  required>
                                <span class="input-group-text"><?php echo e(getCurrencyCode()); ?></span>
                            </div>
                            
                        </div>

                        <input type="hidden" name="curr_code">
                        <div class="col-md-6">
                            <div class="form-label"><?php echo translate('Select Gateway'); ?></div>
                            <select class="form-select method shadow-none" name="gateway">
                                <option value="" selected><?php echo translate('Select'); ?></option>
                                <?php $__currentLoopData = $gateways; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <option value="<?php echo e($item->id); ?>" selected><?php echo e($item->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="col-md-12 my-3 info d-none">
                            <ul class="list-group mt-2">
                                <li class="list-group-item d-flex justify-content-between font-weight-bold"><?php echo translate('Amount : '); ?><span class="exAmount"></span></li>
                            </ul>
                        </div>
                      
                        <div class="col-md-12 mb-3">
                            <div class="form-label">&nbsp;</div>
                            <a href="#" class="btn btn-primary w-100 confirm">
                                <?php echo translate('Confirm'); ?>
                            </a>
                        </div>


                        <div class="modal modal-blur fade" id="modal-success" tabindex="-1" role="dialog" aria-hidden="true">
                            <div class="modal-dialog modal-sm modal-dialog-centered" role="document">
                            <div class="modal-content">
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                <div class="modal-status bg-primary"></div>
                                <div class="modal-body text-center py-4">
                                <i  class="fas fa-info-circle fa-3x text-primary mb-2"></i>
                                <h3><?php echo translate('Confirm Payment'); ?></h3>
                               
                                </div>
                                <div class="modal-footer">
                                <div class="w-100">
                                    <div class="row">
                                    <div class="col"><a href="#" class="btn w-100" data-bs-dismiss="modal">
                                        <?php echo translate('Cancel'); ?>
                                        </a></div>
                                    <div class="col">
                                        <button type="submit" class="btn btn-primary w-100 confirm">
                                           <?php echo translate('Confirm'); ?>
                                        </button>
                                    </div>
                                    </div>
                                </div>
                                </div>
                            </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            </div>
        </div>
    </div>




<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
   <script>
       'use strict';

        $('.method').on('change',function () { 
            var amount = parseFloat($('#amount').val())
            var selected = $('.method option:selected')

            if(selected.val() == '' ){
                $('.info').addClass('d-none')
                return false;
            }
            if($('#amount').val() == ''){
                toast('error','<?php echo translate('Please provide the amount first.'); ?>')
                return false;
            }
            if($('.wallet').val() == ''){
                toast('error','<?php echo translate('Please select the wallet first.'); ?>')
                return false;
            }

            var wallet = $('.wallet option:selected')
            var min = parseFloat(selected.data('min')).toFixed(8)
            var max = parseFloat(selected.data('max')).toFixed(8)
            var fixed = parseFloat(selected.data('fixed')).toFixed(8)
            var percent = parseFloat(selected.data('percent')).toFixed()
            var code = '<?php echo e(getCurrencyCode()); ?>'

            var totalCharge = parseFloat(fixed)+parseFloat((amount * (percent/100)))

            $('.limit').text('Min : '+min+' '+code+' --- '+ 'Max : '+max+' '+code)
            $('.charge').text('Total Charge : '+fixed+' '+code+' + '+percent+'%')

            if(min > amount || max < amount){
                toast('error','Please follow the limit')
                return false;
            }

            $('.info').removeClass('d-none')
            $('.exAmount').text(amount +' '+ code)
            $('.exCharge').text(totalCharge +' '+ code)
            $('.total_amount').text(amount+totalCharge +' '+ code)
            $('.instruction').html(selected.data('ins'))
        })

        $('.confirm').on('click',function () { 
            var selectedMethod = $('.method option:selected')
            var selectedWallet = $('.wallet option:selected')

            if(selectedMethod.val() == '' ){
                $('.info').addClass('d-none')
                toast('error','<?php echo translate('Please select the payment method first.'); ?>')
                return false;
            }
            if($('#amount').val() == ''){
                toast('error','<?php echo translate('Please provide the amount first.'); ?>')
                return false;
            }
            if(selectedWallet.val() == ''){
                toast('error','<?php echo translate('Please select the wallet first.'); ?>')
                return false;
            }

            $('#modal-success').modal('show')
        })
   </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\admin\project\resources\views/user/deposit/index.blade.php ENDPATH**/ ?>