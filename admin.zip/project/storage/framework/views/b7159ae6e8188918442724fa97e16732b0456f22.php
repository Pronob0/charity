 <!-- Sponsors -->
 <section class="sponsor-section pt-50 pb-100">
    <div class="container">
        <div class="section-title text-center">
            <h6 class="subtitle text--base"><?php echo app('translator')->get(@$section->content->title); ?></h6>
            <h2 class="title"><?php echo app('translator')->get(@$section->content->heading); ?></h2>
             <p>
                <?php echo app('translator')->get(@$section->content->sub_heading); ?>
            </p>
        </div>
        <?php if(!empty($section->sub_content)): ?>
            <div class="sponsor-slider owl-theme owl-carousel">
                <?php $__currentLoopData = $section->sub_content; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="sponsor-item">
                        <img src="<?php echo e(getPhoto(@$item->image)); ?>" alt="sponsor">
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
    </div>
</section>
<!-- Sponsors --><?php /**PATH C:\xampp\htdocs\admin\project\resources\views/frontend/sections/sponsors.blade.php ENDPATH**/ ?>