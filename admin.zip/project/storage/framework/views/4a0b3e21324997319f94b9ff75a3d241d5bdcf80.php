

<?php $__env->startSection('title'); ?>
    <?php echo translate('Withdraw Money'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row row-deck row-cards mb-5">
        <div class="col-12">
            <div class="card">
            <div class="card-body">
                <form action="" id="form" method="post">
                  <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-md-6 mb-2">
                            <div class="form-label "><?php echo translate('Amount : '); ?> <code class="limit"></code> </div>
                            <input type="text" name="amount" id="amount" class="form-control shadow-none mb-2"  required>
                            <small class="text-danger charge"></small>
                        </div>

                        <div class="col-md-6">
                            <div class="form-label"><?php echo translate('Select Method'); ?></div>
                            <select class="form-select method shadow-none" name="method_id">
                                <option value="" selected><?php echo translate('Select'); ?></option>
                                <?php $__currentLoopData = $methods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $method): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <option value="<?php echo e($method->id); ?>" data-min="<?php echo e($method->min_amount); ?>" data-max="<?php echo e($method->max_amount); ?>" data-fixed="<?php echo e($method->fixed_charge); ?>" data-percent="<?php echo e($method->percent_charge); ?>" data-ins="<?php echo e($method->withdraw_instruction); ?>"><?php echo e($method->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                       
                        <div class="col-md-12 my-3 info d-none">
                            <ul class="list-group mt-2">
                                <li class="list-group-item d-flex justify-content-between font-weight-bold"><?php echo translate('Withdraw Amount : '); ?><span class="exAmount"></span></li>

                                <li class="list-group-item d-flex justify-content-between font-weight-bold"><?php echo translate('Total Charge : '); ?><span class="exCharge"></span></li>
                                
                                <li class="list-group-item d-flex justify-content-between font-weight-bold"><?php echo translate('Total Amount : '); ?><span class="total_amount"></span></li>
                            </ul>

                            <div class="mt-4 text-center">
                                <h5 class="text-danger">
                                    <?php echo translate('Withdraw instruction'); ?>
                                </h5>
                                <p class="instruction mt-2"></p>
                            </div>

                            <div class="mt-3 text-center">
                                <h5 class="text-danger">
                                    <?php echo translate('Provide your withdraw account details.'); ?>
                                </h5>

                                <textarea name="user_data" id="" class="form-control shadow-none" cols="30" rows="10" required></textarea>
                            </div>
                        </div>
                      
                        <div class="col-md-12 mb-3">
                            <div class="form-label">&nbsp;</div>
                            <a href="#" class="btn btn-primary w-100 confirm">
                                <?php echo translate('Confirm'); ?>
                            </a>
                        </div>


                        <div class="modal modal-blur fade" id="modal-success" tabindex="-1" role="dialog" aria-hidden="true">
                            <div class="modal-dialog modal-sm modal-dialog-centered" role="document">
                            <div class="modal-content">
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                <div class="modal-status bg-primary"></div>
                                <div class="modal-body text-center py-4">
                                <i  class="fas fa-info-circle fa-3x text-primary mb-2"></i>
                                <h3><?php echo translate('Confirm Withdraw'); ?></h3>
                               
                                </div>
                                <div class="modal-footer">
                                <div class="w-100">
                                    <div class="row">
                                    <div class="col"><a href="#" class="btn w-100" data-bs-dismiss="modal">
                                        <?php echo translate('Cancel'); ?>
                                        </a></div>
                                    <div class="col">
                                        <button type="submit" class="btn btn-primary w-100 confirm">
                                           <?php echo translate('Confirm'); ?>
                                        </button>
                                    </div>
                                    </div>
                                </div>
                                </div>
                            </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
   <script>
       'use strict';
        $('.method').on('change',function () { 
            var amount = parseFloat($('#amount').val())
            var selected = $('.method option:selected')

            if(selected.val() == '' ){
                $('.info').addClass('d-none')
                return false;
            }
            if($('#amount').val() == ''){
                toast('error','<?php echo translate('Please provide the amount first.'); ?>')
                return false;
            }
           

            var min = parseFloat(selected.data('min')).toFixed()
            var max = parseFloat(selected.data('max')).toFixed()
            var fixed = parseFloat(selected.data('fixed')).toFixed()
            var percent = parseFloat(selected.data('percent')).toFixed()
            var code = "<?php echo e($gs->curr_code); ?>"

            var totalCharge = parseFloat(fixed)+parseFloat((amount * (percent/100)))

            $('.limit').text('<?php echo translate('Min'); ?> : '+min+' '+code+' --- '+ 'Max : '+max+' '+code)
            $('.charge').text('<?php echo translate('Total Charge'); ?> : '+fixed+' '+code+' + '+percent+'%')

            if(min > amount || max < amount){
                toast('error','<?php echo translate('Please follow the limit'); ?>')
                return false;
            }

            $('.info').removeClass('d-none')
            $('.exAmount').text(amount +' '+ code)
            $('.exCharge').text(totalCharge +' '+ code)
            $('.total_amount').text(amount+totalCharge +' '+ code)
            $('.instruction').html(selected.data('ins'))
        })

        $('.confirm').on('click',function () { 
            var selectedMethod = $('.method option:selected')
            var selectedWallet = $('.wallet option:selected')

            if(selectedMethod.val() == '' ){
                $('.info').addClass('d-none')
                toast('error','<?php echo translate('Please select the withdraw method first.'); ?>')
                return false;
            }
            if($('#amount').val() == ''){
                toast('error','<?php echo translate('Please provide the amount first.'); ?>')
                return false;
            }
            if(selectedWallet.val() == ''){
                toast('error','<?php echo translate('Please select the wallet first.'); ?>')
                return false;
            }
            $('#modal-success').modal('show')
        })
   </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\admin\project\resources\views/user/withdraw/withdraw_form.blade.php ENDPATH**/ ?>