<div class="container card">
    <div class="js-cookie-consent cookie-consent">
        <span class="cookie-consent__message m-2">
            <?php echo app('translator')->get(@$gs->cookie->cookie_text); ?>
        </span>

        <button class="js-cookie-consent-agree cookie-consent__agree cmn--btn m-2">
            <?php echo app('translator')->get(@$gs->cookie->button_text); ?>
        </button>
    </div>
</div><?php /**PATH C:\xampp\htdocs\admin\project\resources\views/frontend/partials/cookie.blade.php ENDPATH**/ ?>