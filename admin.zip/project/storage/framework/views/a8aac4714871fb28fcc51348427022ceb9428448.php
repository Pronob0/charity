

<?php $__env->startSection('title'); ?>
    <?php echo translate('API Documentation'); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
      <!-- Documentation -->
      <section class="documentation-section pt-100 pb-100">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-10">
                    <div class="documentation-wrapper">
                        <div class="documentation-item" id="intro">
                            <div class="documentation-header">
                                <h3 class="title"><?php echo translate('API Endpoints & Authentication'); ?></h3>
                               
                            </div>
                            <p>
                               <?php echo translate(' All requests to the'); ?> <?php echo e($gs->title); ?> <?php echo translate('API are sent via the HTTP POST method to one of our API endpoint URLs'); ?>.

                                <ul>
                                    <li>
                                        <?php echo translate('HTTP Request Method'); ?> : <span class="badge badge--primary">POST</span>
                                    </li>
                                    <li class="mt-2">
                                        <?php echo translate('API Endpoint'); ?> : <a href="javascript:void(0)"><?php echo e(url('payment/process')); ?></a>
                                    </li>
                                    <li class="my-2">
                                        <?php echo translate('JSON Content-Type'); ?> : <span class="badge badge--warning">application/json</span>
                                    </li>
                                </ul>

                                <?php echo translate('All calls to the'); ?> <?php echo e($gs->title); ?> <?php echo translate('API require merchant authentication and merchant access key.'); ?> <a href="<?php echo e(url('merchant/register')); ?>"><?php echo translate('Sign up'); ?></a> <?php echo translate('for a  account to quickly get started'); ?>.
                                <br>
                                <?php echo translate('Sandbox payment can be also initiated while merchant set the service mode as test in merchant dashboard. It will be live while the mode will be set as active mode.'); ?>
                            </p>
                          
                        </div>

                        <div class="documentation-item" id="api">
                            <div class="documentation-header">
                                <h3 class="title"><?php echo translate('API Access Key'); ?></h3>
                            </div>
                            <p>
                               <?php echo translate('Register as a merchant in our system. In your merchant dashboard you will find the option for API access key.'); ?> <br><br>

                               <?php echo translate('Example access key : 51a4bd18-5bc1-4eaa-97b0-c09323398883'); ?>
                            </p>
                            
                        </div>

                        
                        <div class="documentation-item" id="payment">
                            <div class="documentation-header">
                                <h3 class="title"><?php echo translate('Payment Transaction Initiate'); ?></h3>
                            </div>
                            <p>
                                <?php echo translate('The following example code enables you to initiate a payment,depending on how you structure it. The perameter details are also below.'); ?>
                            </p>

                            <table class="table table-bordered text-center bg--section mb-4">
                                <thead class="bg--base">
                                    <tr>
                                        <th class="text--white"><?php echo translate('Param Name'); ?></th>
                                        <th class="text--white"><?php echo translate('Param Type'); ?></th>
                                        <th class="text--white"><?php echo translate('Description'); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>
                                            <?php echo translate('custom'); ?>
                                        </td>
                                        <td>
                                            <?php echo translate('string'); ?>
                                        </td>
                                        <td>
                                            <?php echo translate('Identification of your end'); ?> <span class="badge badge--danger"><?php echo translate('Required'); ?></span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <?php echo translate('amount'); ?>
                                        </td>
                                        <td>
                                            <?php echo translate('decimal'); ?>
                                        </td>
                                        <td>
                                            <?php echo translate('The amount you want to transaction'); ?> <span class="badge badge--danger"><?php echo translate('Required'); ?></span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <?php echo translate('details'); ?>
                                        </td>
                                        <td>
                                            <?php echo translate('string'); ?>
                                        </td>
                                        <td>
                                            <?php echo translate('Purchase details'); ?> <span class="badge badge--danger"><?php echo translate('Required'); ?></span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <?php echo translate('web_hook'); ?>
                                        </td>
                                        <td>
                                            <?php echo translate('string'); ?>
                                        </td>
                                        <td>
                                            <?php echo translate('Instant payment notification url'); ?> <span class="badge badge--danger"><?php echo translate('Required'); ?></span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <?php echo translate('cancel_url'); ?>
                                        </td>
                                        <td>
                                            <?php echo translate('string'); ?>
                                        </td>
                                        <td>
                                            <?php echo translate('Payment cancel return url'); ?> <span class="badge badge--danger"><?php echo translate('Required'); ?></span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <?php echo translate('success_url'); ?>
                                        </td>
                                        <td>
                                            <?php echo translate('string'); ?>
                                        </td>
                                        <td>
                                            <?php echo translate('Payment success return url'); ?> <span class="badge badge--danger"><?php echo translate('Required'); ?></span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <?php echo translate('customer_email'); ?>
                                        </td>
                                        <td>
                                            <?php echo translate('string'); ?>
                                        </td>
                                        <td>
                                            <?php echo translate('Customer email address'); ?> <span class="badge badge--danger"><?php echo translate('Required'); ?></span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <?php echo translate('access_key'); ?>
                                        </td>
                                        <td>
                                            <?php echo translate('string'); ?>
                                        </td>
                                        <td>
                                            <?php echo translate('Send access_key as bearer token with header'); ?> <span class="badge badge--danger"><?php echo translate('Required'); ?></span>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>

                            <pre class="mb-0">
                                <button class="copy-btn" data-clipboard-target="#php-code"><?php echo translate('Copy'); ?></button>
    <code class="language-php" id="php-code">
            &lt;?php
                $parameters = [
                    'custom' => 'DFU80XZIKS',
                    'currency_code' => 'USD',
                    'amount' => 280.00,
                    'details' => 'Digital Product',
                    'web_hook' => 'http://yoursite.com/web_hook.php',
                    'cancel_url' => 'http://yoursite.com/cancel_url.php',
                    'success_url' => 'http://yoursite.com/success_url.php',
                    'customer_email' => 'customer@mail.com',
                ];
                
                $url = 'http://yourwallet.com/payment/process';
                
                $headers = [
                    "Accept: application/json",
                    "Authorization: Bearer access_key",
                ];
                
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
                curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
                curl_setopt($ch, CURLOPT_URL, $url);
                curl_setopt($ch, CURLOPT_POSTFIELDS,  http_build_query($parameters));
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                $response = curl_exec($ch);
                curl_close($ch);
            ?&gt;
    </code>
                            </pre>
                            
                        </div>

                        <div class="documentation-item" id="payment">
                            <div class="documentation-header">
                                <h3 class="title"><?php echo translate('Example Response after initiating payment'); ?></h3>
                            </div>
                            <pre class="mb-0">
                                
        <code class="language-php" id="php-code">
        
            //Success Response.
            {
                "code": 200,
                "status": "ok",
                "payment_id": "AIYmQIOAz0GlmsjfhgiOeu304",
                "message": "Your payment has been processed. Please follow the URL to complete the payment.",
                "url":"<?php echo e(url('/')); ?>/process-checkout?payment_id=AIYmQIOAz0GlmsjfhgiOeu304"
            }

            //Error Response.
            {
                "code": 401,
                "status": "error",
                "message": "Invalid API credentials."
            }
            
            
        </code>
                            </pre>
                            
                        </div>

                        <div class="documentation-item" id="payment">
                            <div class="documentation-header">
                                <h3 class="title"><?php echo translate('Response after successful payment'); ?></h3>
                            </div>
                            <pre class="mb-0">
                                
        <code class="language-php" id="php-code">
        
            //Success Response.
            {
                "code": 200,
                "status": "ok",
                "payment_id": "AIYmQIOAz0GlmsjfhgiOeu304",
                "transaction": "AIYmQIOAz0G",
                "amount": 100.00,
                "charge": 5.00,
                "currency": "USD",
                "custom": "BVSUZ545XCS",
                "date"  : "22-05-2022"
            }

            
        </code>
                            </pre>
                            
                        </div>
                       


                        <div class="documentation-item" id="payment">
                            <div class="documentation-header">
                                <h3 class="title"><?php echo translate('Verify Payment'); ?></h3>
                            </div>
                            <p>
                                <?php echo translate('You can verify the payment whether it is valid or not. After successful payment transaction you will have the response where you find the Payment ID. With this payment id and your access key you need make a request to our server for verify the payment. Example code is below. '); ?><br>  <br>
                                <span><?php echo translate('Payment verify end point : '); ?> <a href="javascript:void(0)"><?php echo e(url('payment/check-validity')); ?></a></span>
                            </p> 

                            <pre class="mb-0">
                                <button class="ver-btn copy-btn" data-clipboard-target="#ver-code"><?php echo translate('Copy'); ?></button>
    <code class="language-php" id="ver-code">
            &lt;?php
                $parameters = [
                    'payment_id' => 'AIYmQIOAz0GlmsjfhgiOeu304',
                ]
                
                $url = '<?php echo e(url('payment/check-validity')); ?>';
                
                $headers = [
                    "Accept: application/json",
                    "Authorization: Bearer access_key",
                ];
                
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
                curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
                curl_setopt($ch, CURLOPT_URL, $url);
                curl_setopt($ch, CURLOPT_POSTFIELDS,  $parameters);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                $response = curl_exec($ch);
                curl_close($ch);
            ?&gt;
    </code>
                            </pre>
                            
                        </div>

                        <div class="documentation-item" id="payment">
                            <div class="documentation-header">
                                <h3 class="title"><?php echo translate('Validity Response'); ?></h3>
                            </div>
                            <pre class="mb-0">
                                
        <code class="language-php" id="php-code">
        
            //Success Response.
            {
                "code": 200,
                "status": "ok",
                "message": "Transaction is valid",
                
            }

            //Error Response.
            {
                "code": 401,
                "status": "error",
                "message": "Invalid API credentials."
            }

            //or
            {
                "code": 404,
                "status": "error",
                "message": "Transaction not found"
            }

            
        </code>
                            </pre>
                            
                        </div>

                         <div class="documentation-item" id="currency">
                            <div class="documentation-header">
                                <h3 class="title"><?php echo translate('Supported Currencies'); ?></h3>
                            </div>
                            <p>
                                <?php echo translate('Following currencies are currently supported in our system. It may update furthur.'); ?>
                            </p>
                            <table class="table table-bordered text-center bg--section mb-0">
                                <thead class="bg--base">
                                    <tr>
                                        <th class="text--white"><?php echo translate('Currency Name'); ?></th>
                                        <th class="text--white"><?php echo translate('Currency Symbol'); ?></th>
                                        <th class="text--white"><?php echo translate('Currency Code'); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $currencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                               <?php echo e($item->curr_name); ?>

                                            </td>
                                            <td>
                                                <?php echo e($item->symbol); ?>

                                            </td>
                                            <td>
                                                <?php echo e($item->code); ?>

                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                   
                                </tbody>
                            </table>
                        </div>
                       
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Documentation -->

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script src="<?php echo e(asset('assets/frontend')); ?>/js/highlight.min.js"></script>
<script>
    hljs.highlightAll();
</script>

<script src="<?php echo e(asset('assets/frontend')); ?>/js/clipboard.min.js"></script>
<script>
    new ClipboardJS('.copy-btn');
    new ClipboardJS('.ver-btn');
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\admin\project\resources\views/frontend/api_doc.blade.php ENDPATH**/ ?>