

<?php $__env->startSection('title'); ?>
  <?php echo translate('Withdraw Methods'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
 <section class="section">
    <div class="section-header justify-content-between">
        <h1><?php echo translate('Withdraw Methods'); ?></h1>
        <?php if(access('withdraw method create')): ?>
        <a href="<?php echo e(route('admin.withdraw.create')); ?>" class="btn btn-primary add"><i class="fa fa-plus"></i> <?php echo translate('Add new Method'); ?></a>
            
        <?php endif; ?>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header justify-content-end">
                    <div class="card-header-form">
                        <form method="GET" action="<?php echo e(route('admin.withdraw.search')); ?>">
                            <div class="input-group">
                                <input type="text" class="form-control" name="search">
                                <div class="input-group-append">
                                    <button class="btn btn-primary border-0"><i class="fas fa-search"></i></button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="card-body">
                    <div class="card-body text-center">
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <tr>
                                    <th><?php echo translate('Sl'); ?></th>
                                    <th><?php echo translate('Name'); ?></th>
                                    <th><?php echo translate('status'); ?></th>
                                    <th><?php echo translate('Action'); ?></th>
                                </tr>
                                <?php $__empty_1 = true; $__currentLoopData = $withdraws; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $withdraw): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>

                                        <td data-label="<?php echo translate('Sl'); ?>"><?php echo e($key +  $withdraws->firstItem()); ?></td>
                                        <td data-label="<?php echo translate('Name'); ?>"><?php echo e($withdraw->name); ?></td>

                                        <td data-label="<?php echo translate('status'); ?>">
                                            <?php if($withdraw->status): ?>
                                                <div class="badge badge-success"><?php echo translate('Active'); ?></div>
                                            <?php else: ?>
                                                <div class="badge badge-danger"><?php echo translate('Inactive'); ?></div>
                                            <?php endif; ?>
                                        </td>

                                        <?php if(access('withdraw method edit')): ?>
                                        <td data-label="<?php echo translate('Action'); ?>">
                                            <a href="<?php echo e(route('admin.withdraw.edit', $withdraw->id)); ?>"  class="btn btn-primary update"><i class="fa fa-pen"></i></a>
                                        </td>
                                        <?php else: ?>
                                        <?php echo translate('N/A'); ?>
                                        <?php endif; ?>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                                    <tr>

                                        <td class="text-center" colspan="100%"><?php echo translate('No Data Found'); ?></td>

                                    </tr>

                                <?php endif; ?>
                            </table>
                        </div>
                    </div>
                    <?php if($withdraws->hasPages()): ?>
                        <div class="card-footer">
                            <?php echo e($withdraws->links('admin.partials.paginate')); ?>

                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\admin\project\resources\views/admin/withdraw/index.blade.php ENDPATH**/ ?>