

<?php $__env->startSection('title'); ?>
   <?php echo translate('Edit Gateway : '.$paymentgateway->name); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
 <section class="section">
    <div class="section-header justify-content-between">
        <h1> <?php echo translate('Edit Gateway : '.$paymentgateway->name); ?></h1>
        <a href="<?php echo e(route('admin.gateway')); ?>" class="btn btn-primary"><i class="fas fa-backward"></i> <?php echo translate('Back'); ?></a>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row justify-content-center mt-3">
   <div class="col-lg-12">
      <div class="card mb-4">
         <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
            <h6 class="m-0 font-weight-bold text-primary"><?php echo e(__('Edit Gateway')); ?></h6>
         </div>
         <div class="card-body">
            <div class="gocover" style="background: url(<?php echo e(asset('assets/images/'.$gs->dashboard_loader)); ?>) no-repeat scroll center center rgba(45, 45, 45, 0.5);"></div>
            <form  action="<?php echo e(route('admin.gateway.update',$paymentgateway)); ?>" method="POST" enctype="multipart/form-data">
             <?php echo csrf_field(); ?>
              
              <?php echo $__env->make('admin.partials.form-both', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              <?php if($paymentgateway->type == 'automatic'): ?>
             
              <div class="form-group row mb-3">
                <label for="name" class="col-sm-4 col-form-label"><?php echo e(__('Name')); ?></label>
                <div class="col-sm-8">
                   <input type="text" class="form-control" id="name" name="name" placeholder="<?php echo e(__('Gateway Name')); ?>" value="<?php echo e($paymentgateway->name); ?>">
                </div>
              </div>

              
               <?php if($paymentgateway->information != null): ?>
                  <?php $__currentLoopData = $paymentgateway->convertAutoData(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pkey => $pdata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <?php if($pkey != 'sandbox_check'): ?>
                        <div class="form-group row mb-3">
                        <label  class="col-sm-4 col-form-label"><?php echo e(__( $paymentgateway->name.' '.ucwords(str_replace('_',' ',$pkey)) )); ?> *</label>
                        <div class="col-sm-8">
                           <input type="text" class="form-control" name="pkey[<?php echo e(__($pkey)); ?>]" value="<?php echo e($pdata); ?>" <?php echo e($pdata == 1 ? "checked":""); ?>>
                        </div>
                     </div>
                     <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  
                  <?php $__currentLoopData = $paymentgateway->convertAutoData(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pkey => $pdata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <?php if($pkey == 'sandbox_check'): ?>
                     <div class="custom-control custom-checkbox">
                        <input type="checkbox" name="pkey[<?php echo e(__($pkey)); ?>]" class="custom-control-input" value="1" id="customCheck1" <?php echo e($pdata == 1 ? "checked":""); ?>>
                        <label class="custom-control-label" for="customCheck1"><?php echo e(__( $paymentgateway->name.' '.ucwords(str_replace('_',' ',$pkey)) )); ?> *</label>
                    </div>
                     <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <div class="form-group row mb-3">
                     <label for="name" class="col-sm-4 col-form-label"><?php echo e(__('Status')); ?></label>
                     <div class="col-sm-8">
                       <select name="status" class="form-control">
                          <option value="1" <?php echo e($paymentgateway->status == 1 ? 'selected':''); ?>><?php echo translate('Active'); ?></option>
                          <option value="0" <?php echo e($paymentgateway->status == 0 ? 'selected':''); ?>><?php echo translate('Inactive'); ?></option>
                       </select>
                     </div>
                   </div>

                  <hr>
                  <?php
                     $setCurrency = $paymentgateway->currency_id;
                     if($setCurrency == 0){
                        $setCurrency = [];
                     }
                  ?>
                  <?php $__currentLoopData = DB::table('currencies')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dcurr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 
                     <input  name="currency_id[]" <?php echo e(in_array($dcurr->id,$setCurrency) ? 'checked' : ''); ?> type="checkbox" id="currency_id<?php echo e($dcurr->id); ?>" value="<?php echo e($dcurr->id); ?>">
                     <label class=" mr-4" for="currency_id<?php echo e($dcurr->id); ?>"><?php echo e($dcurr->code); ?></label>
                
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  
                <?php endif; ?>
          
                <?php else: ?>

              
               <div class="row">
                  <div class="form-group col-md-6">
                     <label for="name"><?php echo e(__('Name')); ?></label>
                     <input type="text" class="form-control" name="title" id="name" placeholder="<?php echo e(__('Name')); ?>" value="<?php echo e($paymentgateway->title); ?>">
                 </div>   
             
                 <div class="form-group col-md-6">
                     <label for="subtitle"><?php echo e(__('Subtitle')); ?></label>
                     <input type="text" class="form-control" id="subtitle" name="subtitle" placeholder="<?php echo e(__('Subtitle')); ?>" value="<?php echo e($paymentgateway->subtitle); ?>">
                 </div>
                 
                 <div class="form-group col-md-6">
                     <label for="subtitle"><?php echo e(__('Fixed Charge')); ?></label>
                     <div class="input-group">
                        <input type="text" class="form-control" id="fixed_charge" name="fixed_charge" placeholder="<?php echo e(__('Fix Charge')); ?>"  value="<?php echo e(numFormat($paymentgateway->fixed_charge)); ?>">
                        <div class="input-group-append">
                           <span class="input-group-text" id="my-addon"><?php echo e($gs->curr_code); ?></span>
                        </div>
                     </div>
                 </div>
                 
                 <div class="form-group col-md-6">
                     <label for="subtitle"><?php echo e(__('Percent Charge')); ?></label>
                     <div class="input-group">
                        <input type="text" class="form-control" id="subtitle" name="percent_charge" placeholder="<?php echo e(__('Percent Charge')); ?>" value="<?php echo e($paymentgateway->percent_charge); ?>">
                        <div class="input-group-append">
                           <span class="input-group-text" id="my-addon">%</span>
                        </div>
                     </div>
                 </div>

                 <div class="form-group col-md-12 mb-3">
                  <label for="name"><?php echo e(__('Status')); ?></label>
                    <select name="status" class="form-control">
                       <option value="1" <?php echo e($paymentgateway->status == 1 ? 'selected':''); ?>><?php echo translate('Active'); ?></option>
                       <option value="0" <?php echo e($paymentgateway->status == 0 ? 'selected':''); ?>><?php echo translate('Inactive'); ?></option>
                    </select>
                  
                </div>
                 
                 <div class="form-group col-md-12">
                     <label for="details"><?php echo e(__('Description')); ?></label>
                     <textarea id="area1" class="form-control summernote" rows="10" name="details" placeholder="<?php echo e(__('Description ')); ?>"><?php echo e($paymentgateway->details); ?></textarea>
                 </div>

                 <hr>
                 <?php
                     $setCurrency = $paymentgateway->currency_id;
                     if($setCurrency == 0){
                        $setCurrency = [];
                     }
                  ?>
                  <div class="col-md-12">
                  <?php $__currentLoopData = DB::table('currencies')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dcurr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <input  name="currency_id[]" <?php echo e(in_array($dcurr->id,$setCurrency) ? 'checked' : ''); ?> type="checkbox" id="currency_id<?php echo e($dcurr->id); ?>" value="<?php echo e($dcurr->id); ?>">
                     <label class="mr-4" for="currency_id<?php echo e($dcurr->id); ?>"><?php echo e($dcurr->code); ?></label>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
               </div>
               <?php endif; ?>
          
                <div class="form-group row mt-4 ">
                  <div class="col-sm-12 text-right">
                     <button type="submit" class="btn btn-primary btn-lg"><?php echo e(translate('Update')); ?></button>
                  </div>
               </div>
          </form>
         </div>
      </div>
   </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\admin\project\resources\views/admin/payment/edit.blade.php ENDPATH**/ ?>