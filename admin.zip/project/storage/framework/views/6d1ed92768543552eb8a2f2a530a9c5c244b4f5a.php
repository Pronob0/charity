<!-- Blog -->
<?php
    $blogs = App\Models\Blog::where('status',1)->whereHas('category',function($q){
        $q->where('status',1);
    })->latest()->inRandomOrder()->take(3)->get();
?>
<section class="blog-section my-4">
    <div class="container">
        <div class="card">
            <div class="card-body">
                <div class="section-title text-center mb-4">
                    <h6 class="subtitle text--base"><?php echo app('translator')->get(@$section->content->title); ?></h6>
                    <h2 class="title"><?php echo app('translator')->get(@$section->content->heading); ?></h2>
                    <p>
                        <?php echo app('translator')->get(@$section->content->sub_heading); ?>
                    </p>
                </div>
                <div class="row justify-content-center gy-4">
                    <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-4 col-md-6 col-sm-10">
                            <div class="blog__item">
                                <div class="blog__item-img">
                                    <a href="<?php echo e(route('blog.details',[$item->id,$item->slug])); ?>">
                                        <img class="w-50" src="<?php echo e(getPhoto($item->photo)); ?>" alt="blog">
                                    </a>
                                </div>
                                <div class="blog__item-content">
                                   
                                    <h5 class="blog__item-content-title">
                                        <a href="<?php echo e(route('blog.details',[$item->id,$item->slug])); ?>">
                                           <?php echo e(translate(Str::limit($item->title,30))); ?>

                                        </a>
                                    </h5>
                                    <a href="<?php echo e(route('blog.details',[$item->id,$item->slug])); ?>" class="read-more"><?php echo translate('Read More'); ?></a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
        
    </div>
</section>
<!-- Blog --><?php /**PATH C:\xampp\htdocs\admin\project\resources\views/frontend/sections/blog.blade.php ENDPATH**/ ?>