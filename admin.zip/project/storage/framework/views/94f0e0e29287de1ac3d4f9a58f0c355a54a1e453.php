

<?php $__env->startSection('title'); ?>
   <?php echo translate('Deposits'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
 <section class="section">
    <div class="section-header">
        <h1><?php echo translate('Deposits'); ?></h1>
        
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
        
<div class="row">
    <div class="col-12 col-md-12 col-lg-12">
        <div class="card">
            <div class="card-header d-flex justify-content-end">
                <form action="" class="d-flex flex-wrap justify-content-end">
                    <div class="form-group m-1 flex-grow-1">
                     <select class="form-control" onChange="window.location.href=this.value">
                         <option value="<?php echo e(filter('status','')); ?>"><?php echo translate('All Deposits'); ?></option>
                     
                         <option value="<?php echo e(filter('status','pending')); ?>" <?php echo e(request('status')=='pending'?'selected':''); ?>><?php echo translate('Pending Deposits'); ?></option>
                      
                         <option value="<?php echo e(filter('status','completed')); ?>" <?php echo e(request('status')=='completed'?'selected':''); ?>><?php echo translate('Completed Deposits'); ?></option>

                         <option value="<?php echo e(filter('status','rejected')); ?>" <?php echo e(request('status')=='rejected'?'selected':''); ?>><?php echo translate('Rejected Deposits'); ?></option>
                     </select>
                    </div>
                    
                     <div class="form-group m-1 flex-grow-1">
                         <div class="input-group">
                             <input type="text" class="form-control" name="search" value="<?php echo e($search ?? ''); ?>" placeholder="<?php echo translate('Transaction ID'); ?>">
                             <div class="input-group-append">
                                 <button class="input-group-text btn btn-primary text-white" id="my-addon"><i class="fas fa-search"></i></button>
                             </div>
                         </div>
                     </div>
                </form>
            </div>
            <div class="card-body text-center">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <tr>
                            <th><?php echo translate('Transaction ID'); ?></th>
                            <th><?php echo translate('User'); ?></th>
                            <th><?php echo translate('Amount(With Charge)'); ?></th>
                            <th><?php echo translate('Charge'); ?></th>
                            <th><?php echo translate('Method'); ?></th>
                            <th><?php echo translate('Status'); ?></th>
                            <th><?php echo translate('Details'); ?></th>
                            <th><?php echo translate('Action'); ?></th>
                        </tr>
                        <?php $__empty_1 = true; $__currentLoopData = $deposits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>

                                 <td data-label="<?php echo translate('Transaction ID'); ?>">
                                   <?php echo e($info->txn_id); ?>

                                 </td>
                                 <td data-label="<?php echo translate('User'); ?>"><?php echo e($info->user->email); ?></td>
                                 <td data-label="<?php echo translate('Amount'); ?>"><?php echo e(amount($info->amount,$info->currency->type,2)); ?> <?php echo e($info->currency->code); ?></td>
                                 <td data-label="<?php echo translate('Charge'); ?>"><?php echo e(amount($info->charge,$info->currency->type,2)); ?> <?php echo e($info->currency->code); ?></td>
                                 <td data-label="<?php echo translate('Method'); ?>"><?php echo e($info->gateway->name); ?></td>
                                 <td data-label="<?php echo translate('Status'); ?>">
                                    <?php if($info->status == 'pending'): ?>
                                    <span class="badge badge-warning"> <?php echo e(ucfirst($info->status)); ?> </span>
                                    <?php elseif($info->status == 'rejected'): ?>
                                    <span class="badge badge-danger"> <?php echo e(ucfirst($info->status)); ?> </span>
                                    <?php else: ?>
                                    <span class="badge badge-success"> <?php echo e(ucfirst($info->status)); ?> </span>
                                    <?php endif; ?>
                                 </td>
                               
                                 <td data-label="<?php echo translate('Details'); ?>">
                                    <small><?php echo e($info->trx_details  ?? 'N/A'); ?></small>
                                 </td>

                                 <td data-label="<?php echo translate('Action'); ?>">
                                    <div class="d-flex flex-wrap flex-lg-nowrap align-items-center justify-content-end justify-content-lg-center">
                                        <?php if($info->status == 'pending'): ?>
                                        <a href="javascript:void()" class="btn btn-primary approve btn-sm m-1" data-id="<?php echo e($info->id); ?>" data-toggle="tooltip" title="<?php echo translate('Approve'); ?>"><i class="fas fa-check"></i></a>
     
                                        <a href="javascript:void()" class="btn btn-danger reject btn-sm m-1" data-id="<?php echo e($info->id); ?>"data-toggle="tooltip" title="<?php echo translate('Reject'); ?>"><i class="fas fa-ban"></i></a>
                                        <?php else: ?>
                                        <a href="javascript:void()" class="btn btn-primary disabled btn-sm m-1"><i class="fas fa-check"></i></a>
     
                                        <a href="javascript:void()" class="btn btn-danger disabled btn-sm m-1"><i class="fas fa-ban"></i></a>
                                        <?php endif; ?>
                                    </div>
                                 </td>
                            </tr>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                            <tr>
                                <td class="text-center" colspan="100%"><?php echo translate('No Data Found'); ?></td>
                            </tr>

                        <?php endif; ?>
                    </table>
                </div>
            </div>
            <?php if($deposits->hasPages()): ?>
                <?php echo e($deposits->links()); ?>

            <?php endif; ?>
        </div>
    </div>
</div>

<div id="approveModal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <form action="<?php echo e(route('admin.approve.deposit')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="id">
            <div class="modal-content">
                <div class="modal-body">
                    <h6 class="mt-3"><?php echo translate('Are you sure to approve?'); ?></h6>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-dark" data-dismiss="modal"><?php echo translate('Close'); ?></button>
                    <button type="submit" class="btn btn-primary"><?php echo translate('Confirm'); ?></button>
                </div>
            </div>
        </form>
    </div>
</div>
<div id="rejectModal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <form action="<?php echo e(route('admin.reject.deposit')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="id">
            <div class="modal-content">
                <div class="modal-body">
                    <h6 class="mt-3"><?php echo translate('Are you sure to reject?'); ?></h6>

                    <div class="form-group">
                        <label><?php echo translate('Reject Reasons'); ?></label>
                        <textarea name="reject_reason" class="form-control mt-2"  rows="5"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-dark" data-dismiss="modal"><?php echo translate('Close'); ?></button>
                    <button type="submit" class="btn btn-danger"><?php echo translate('Confirm'); ?></button>
                </div>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        'use strict';
        $('.approve').on('click',function () { 
            $('#approveModal').find('input[name=id]').val($(this).data('id'))
            $('#approveModal').modal('show')
        })
        $('.reject').on('click',function () { 
            $('#rejectModal').find('input[name=id]').val($(this).data('id'))
            $('#rejectModal').modal('show')
        })
    </script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\admin\project\resources\views/admin/deposit/index.blade.php ENDPATH**/ ?>