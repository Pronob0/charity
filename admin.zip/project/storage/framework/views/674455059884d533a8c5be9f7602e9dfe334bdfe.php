

<?php $__env->startSection('title'); ?>
   <?php echo translate('Deposit History'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <?php echo translate('Deposit History'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="row row-deck row-cards">
        <div class="col-12">
            <div class="card">
                <div class="table-responsive">
                  <table class="table table-vcenter card-table table-striped">
                    <thead>
                      <tr>
                        <th><?php echo translate('Amount'); ?></th>
                        <th><?php echo translate('Charge'); ?></th>
                        <th><?php echo translate('Method'); ?></th>
                        <th><?php echo translate('Status'); ?></th>
                        <th><?php echo translate('Date'); ?></th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php $__empty_1 = true; $__currentLoopData = $deposits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
           
                        <tr>
                          <td data-label="<?php echo translate('Amount'); ?>"><?php echo e(amount($item->amount,$item->currency->type,2)); ?> <?php echo e($item->currency->code); ?></td>
                          <td data-label="<?php echo translate('Charge'); ?>"><?php echo e(amount($item->charge,$item->currency->type,2)); ?> <?php echo e($item->currency->code); ?></td>
                          <td data-label="<?php echo translate('Method'); ?>"><?php echo e($item->gateway->name); ?></td>
                          <td data-label="<?php echo translate('Status'); ?>"><span class="badge <?php echo e($item->status == 'completed' ? 'bg-success':'bg-warning'); ?>"><?php echo e($item->status); ?></span></td>
                          <td data-label="<?php echo translate('Date'); ?>"><?php echo e(dateFormat($item->created_at)); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td class="text-center" colspan="12"><?php echo translate('No data found!'); ?></td>
                        </tr>
                      <?php endif; ?>
                    </tbody>
                  </table>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\admin\project\resources\views/user/deposit/history.blade.php ENDPATH**/ ?>