

<nav class="navbar navbar-expand-lg navbar-light bg-light my-3">
    <div class="container-fluid">
      <a class="navbar-brand" href="<?php echo e(url('/')); ?>">Home</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
            <?php $__currentLoopData = json_decode($gs->menu); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="nav-item">
               <a class="nav-link active" target="<?php echo e($item->target == 'self' ? '':'_blank'); ?>" href="<?php echo e(url($item->href)); ?>"><?php echo e(translate($item->title)); ?></a>
            </li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php if(auth()->guard()->check()): ?>
            <li class="nav-item">
                <a  class="nav-link" href="<?php echo e(route('user.dashboard')); ?>" class="cmn--btn"><?php echo translate('Dashboard'); ?></a>
            </li>
            <li class="nav-item">
                <a  class="nav-link" href="<?php echo e(route('user.logout')); ?>" class="cmn--btn btn-outline"><?php echo translate('Logout'); ?></a>
            </li>
            <?php else: ?>
            <li class="nav-item">
                <a  class="nav-link" href="<?php echo e(route('user.login')); ?>" class="cmn--btn"><?php echo translate('Login'); ?></a>
            </li>
            <li class="nav-item">
                <a  class="nav-link" href="<?php echo e(route('user.register')); ?>" class="cmn--btn"><?php echo translate('Register'); ?></a>
            </li>
            <?php endif; ?>
     
         
         
          <li class="nav-item ms-5">
              <select class="language-bar form-control shadow-none" onChange="window.location.href=this.value">
                  <?php $__currentLoopData = DB::table('languages')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e(route('lang.change',$item->code)); ?>" <?php echo e(session('lang') == $item->code ? 'selected':''); ?>><?php echo translate($item->language); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
          </li>
  
     
         
        </ul>
      </div>
    </div>
  </nav><?php /**PATH C:\xampp\htdocs\admin\project\resources\views/frontend/partials/header.blade.php ENDPATH**/ ?>